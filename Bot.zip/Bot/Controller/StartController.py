from telegram import *
from telegram.ext import *

def startCommand(update: Update, context: CallbackContext):
    main_buttons = [[KeyboardButton(text="/Start")]]
    buttons = [
        [InlineKeyboardButton("About", callback_data="about")],
        [InlineKeyboardButton("History ", callback_data="history")],
        [InlineKeyboardButton("Courses ", callback_data="courses")],
        [InlineKeyboardButton("Syllabus ", callback_data="syllabus")],
        [InlineKeyboardButton("Old Papers", callback_data="oldpaper")],
        [InlineKeyboardButton("Time Table", callback_data="timetable")]
    ]
    context.bot.send_message(chat_id=update.effective_chat.id,text="I can help you find Information of Cources. Simply use the buttons below.", reply_markup=InlineKeyboardMarkup(buttons, n_cols=2))
    context.bot.send_message(chat_id=update.effective_chat.id,text="Select Option And Get All Information", reply_markup=ReplyKeyboardMarkup(main_buttons,resize_keyboard=True))