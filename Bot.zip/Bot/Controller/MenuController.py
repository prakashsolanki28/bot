from Controller.AcademicsController import *
from Controller.AboutController import *
def startMenuAction(update: Update, context:CallbackContext):
	query = update.callback_query
	if query.data in "Start":
		context.bot.send_message('/start')
	elif(query.data in "about"):
		AboutController(update,context)
	elif(query.data in "syllabus"):
		syllabusCommand(update,context)
	elif(query.data in "courses"):
		CourseCommand(update,context)
	elif(query.data in "syllabus-bsc"):
		syllabusDownload(update,context, 0)
	elif (query.data in "syllabus-bca"):
		syllabusDownload(update, context, 1)
	elif (query.data in "syllabus-mca"):
		syllabusDownload(update, context, 2)
	elif (query.data in "syllabus-bba"):
		syllabusDownload(update, context, 3)
	elif (query.data in "syllabus-mba"):
		syllabusDownload(update, context, 4)
	elif (query.data in "syllabus-syllabus-b-pharma"):
		syllabusDownload(update, context, 5)
	elif (query.data in "syllabus-syllabus-d-pharma"):
		syllabusDownload(update, context, 5)
