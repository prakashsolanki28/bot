from requests import *
from telegram import *
from telegram.ext import *
def AboutController(update: Update, context: CallbackContext):
    image = get("https://www.lachoomemorial.org/admission/mcp/uploads/slider/1900x700/b74f8916ba1caf57bc93c58791b73027.jpg").content
    context.bot.sendMediaGroup(chat_id=update.effective_chat.id, media=[InputMediaPhoto(image,caption="Lachoo Memorial College of Science & Technology, a modest creation of the year 1965, has travelled an incredible journey of more than five decades. For concepts savoured by visionary Shri Mathuradas Mathur, a connoisseur of higher education in science and technology, this institution has come up synonymous with impeccable acedemic standards preferred for pursuing multi-disciplinary graduate and post-graduate programmes in the field of science, computers, pharmacy, bio-technolgy and management.")])
    update.callback_query.message.edit_text("About Of Lachoo")