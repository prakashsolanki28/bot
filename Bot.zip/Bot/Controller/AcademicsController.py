from telegram import *
from telegram.ext import *
from PIL import Image
import prettytable as pt
from telegram import ParseMode

def CourseCommand(update: Update, context: CallbackContext):
    # table = pt.PrettyTable(['Course', 'Stream', 'Duration'])
    # table.align['Course'] = 'l'
    # table.align['Stream'] = 'l'
    # table.align['Duration'] = 'l'
    # context.bot.send_message(update.effective_user.id, "... Under Graduate Courses ...")
    # data = [
    #     ('B.C.A', 'Computer Application', '3 year (6 semester)'),
    #     ('B.B.A', 'Commerce & Management Studies', '3 year (6 semester)'),
    #     ('B.S.C', '1. Computer Science, Mathematics, Physics', '3 year (6 semester)'),
    #     ('', '2. Biotechnology, Chemistry, Botany', ''),
    #     ('', '3. Biotechnology, Chemistry, Zoology', ''),
    #     ('', '4. Chemistry, Zoology, Botany', ''),
    #     ('', '5. Electronics, Mathematics, Physics', ''),
    #     ('', '6. Chemistry, Zoology Public Health', ''),
    #     ('B.Pharm','Pharmaceutical Science', '4 year (8 semester)'),
    #     ('B.Com','Commerce & Management Studies', '3 year (6 semester)'),
    # ]
    # for Course, Stream, Duration in data:
    #     table.add_row([Course, Stream, Duration])
    # context.bot.send_message(update.effective_user.id,f'<pre>{table}</pre>', parse_mode=ParseMode.HTML)
    context.bot.send_message(update.effective_user.id, "+ -- Under Graduate Courses -- +")
    table = pt.PrettyTable(['Course'])
    table.align['Course'] = 'l'
    data = [
        ('B.C.A - 3 year(6 sem)'),
        ('B.B.A - 3 year(6 sem)'),
        ('B.S.C - 3 year(6 sem)'),
        ('B.Pharm - 4 year(8 sem)'),
        ('B.Com - 3 year(6 sem)'),
    ]
    for Course in data:
        table.add_row([Course])
    context.bot.send_message(update.effective_user.id,f'<pre>{table}</pre>', parse_mode=ParseMode.HTML)
    # Diploma
    context.bot.send_message(update.effective_user.id, "+ --- Diploma Courses --- +")
    table = pt.PrettyTable(['Course'])
    table.align['Course'] = 'l'
    data = [
        ('D. Pharm. - 2 year')
    ]
    for Course in data:
        table.add_row([Course])
    context.bot.send_message(update.effective_user.id, f'<pre>{table}</pre>', parse_mode=ParseMode.HTML)

    # Post Gradu..
    context.bot.send_message(update.effective_user.id, "+ -- Post Graduate Courses -- +")
    table = pt.PrettyTable(['Course'])
    table.align['Course'] = 'l'
    data = [
        ('M.Sc - 2 year(4 sem)'),
        ('M.C.A - 2 year(4 sem)'),
        ('M.B.A - 2 year(4 sem)'),
    ]
    for Course in data:
        table.add_row([Course])
    context.bot.send_message(update.effective_user.id, f'<pre>{table}</pre>', parse_mode=ParseMode.HTML)

    # phd..
    context.bot.send_message(update.effective_user.id, "+ -- Ph.D. -- +")
    table = pt.PrettyTable(['Stream'])
    table.align['Stream'] = 'l'
    data = [
        ('Pharmaceutical Science'),
        ('Botany & Biotechnology'),
        ('Zoology'),
        ('Chemistry'),
        ('Physics')
    ]
    for Course in data:
        table.add_row([Course])
    context.bot.send_message(update.effective_user.id, f'<pre>{table}</pre>', parse_mode=ParseMode.HTML)
    context.bot.send_message(update.effective_user.id,'COURSES - <a href="https://www.lachoomemorial.org/lachoo-courses.php">Read More</a>', parse_mode=ParseMode.HTML)

def syllabusCommand(update: Update, context: CallbackContext):
    update.callback_query.message.edit_text("Download Syllabus " + "\uD83D\uDCC4")
    buttons = [
        [InlineKeyboardButton("BSC", callback_data="syllabus-bsc")],
        [InlineKeyboardButton("BCA ", callback_data="syllabus-bca")],
        [InlineKeyboardButton("MCA ", callback_data="syllabus-mca")],
        [InlineKeyboardButton("BBA ", callback_data="syllabus-bba")],
        [InlineKeyboardButton("MBA ", callback_data="syllabus-mba")],
        [InlineKeyboardButton("B PHARMA ", callback_data="syllabus-b-pharma")],
        [InlineKeyboardButton("D PHARMA ", callback_data="syllabus-d-pharma")]
    ]
    context.bot.sendMessage(chat_id=update.effective_chat.id, text="Plese Select Your Course ...",
                            reply_markup=InlineKeyboardMarkup(buttons))


def syllabusDownload(update: Update, context: CallbackContext, type):
    sub = [
            'https://www.lachoomemorial.org/admission/mcp/uploads/syllabus/BSC0SYLLABUS-COMBINED.pdf',
            'https://www.lachoomemorial.org/admission/mcp/uploads/syllabus/f8385c6858c3ee197829caabf5e0521f.pdf',
            'https://www.lachoomemorial.org/admission/mcp/uploads/syllabus/3fa2bb0a4db404f1bc60495798fbe6f2.pdf',
            'https://www.lachoomemorial.org/admission/mcp/uploads/syllabus/c2cd98a81ad9b19c28406c1cdc41bb71.pdf',
            'https://www.lachoomemorial.org/admission/mcp/uploads/syllabus/9d21fac98740f11226b6f02cd8b3c14c.pdf',
            'https://www.lachoomemorial.org/admission/mcp/uploads/syllabus/011cf5d346101b0d0342c8a809bfcc39.pdf',
            'https://www.lachoomemorial.org/admission/mcp/uploads/syllabus/ed4539762991a89b83de96f4e630e708.pdf'
    ]
    update.callback_query.message.edit_text("please wait few seconds ...")
    context.bot.sendDocument(update.effective_chat.id,sub[type])
