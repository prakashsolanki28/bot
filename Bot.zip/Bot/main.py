from Controller.StartController import *
from Controller.MenuController import *
updater = Updater(token="5907828291:AAGAhBsp9DbzcU1WLpiiLHF0AehFskMd10k")
dispatcher = updater.dispatcher

def helpCommand(update: Update, context: CallbackContext):
    """Displays info on how to use the bot."""
    context.bot.send_message(update.effective_user.id,"Use /start to test this bot.")

dispatcher.add_handler(CommandHandler("start", startCommand))
dispatcher.add_handler(CallbackQueryHandler(startMenuAction))
dispatcher.add_handler(CommandHandler('help',helpCommand))
updater.start_polling()




